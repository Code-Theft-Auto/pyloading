# Pyloading
___
### __Loading made easy!__
___This can Easily be used anywhere in programs(__console based__)___

___Pyloading contains a clear screen for all the OS.___\
___It also have two console based loading screens - rotating one and a common loading bar.___

***
#### To implement Pyloading
**steps:**

1. open `cmd` and type `pip install pyloading`

2. open a python file 

3. ***type in the following***
```python
import pyloading as pyl
pyl.loadingC()
pyl.loading_bar()
pyl.cls()
```
__and your done!__

__All the functions have parameters (_exept cls_) which can be used to change the functionallity of them__

____


Source code available at [github](https://github.com/DevER-M/pyloading)

*Pyloading uses:*
* *itertools*
* *os*
* *threading*
* *time*
* *sys*
* *tqdm*
* *time*